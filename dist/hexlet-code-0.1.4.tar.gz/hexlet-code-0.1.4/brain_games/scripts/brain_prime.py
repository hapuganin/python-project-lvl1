#!/usr/bin/env python

from brain_games.games import prime


def main():
    print('Welcome to the Brain Games!!')
    prime.start()


if __name__ == '__main__':
    main()
